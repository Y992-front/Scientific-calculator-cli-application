#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

int main() {
    vector<float> numbers;
    vector<char> operators;
    char choice;

    do {
        cout << "\nScientific Calculator\n";
        cout << "1. Addition (+)\n";
        cout << "2. Subtraction (-)\n";
        cout << "3. Multiplication (*)\n";
        cout << "4. Division (/)\n";
        cout << "5. Power (^)\n";
        cout << "6. Square Root (sqrt)\n";
        cout << "7. Cube Root (cbrt)\n";
        cout << "8. Sine (sin)\n";
        cout << "9. Cosine (cos)\n";
        cout << "10. Tangent (tan)\n";
        cout << "11. Inverse Sine (asin)\n";
        cout << "12. Inverse Cosine (acos)\n";
        cout << "13. Inverse Tangent (atan)\n";
        cout << "Enter your choice (1-13): ";
        int option;
        cin >> option;

        char op;
        switch (option) {
            case 1:
                op = '+';
                break;
            case 2:
                op = '-';
                break;
            case 3:
                op = '*';
                break;
            case 4:
                op = '/';
                break;
            case 5:
                op = '^';
                break;
            case 6:
                op = 's';
                break;
            case 7:
                op = 'c';
                break;
            case 8:
                op = 'S';
                break;
            case 9:
                op = 'C';
                break;
            case 10:
                op = 'T';
                break;
            case 11:
                op = 'A';
                break;
            case 12:
                op = 'B';
                break;
            case 13:
                op = 'M';
                break;
            default:
                cout << "Invalid option." << endl;
                continue;
        }

        cout << "Enter a number: ";
        float num;
        cin >> num;
        numbers.push_back(num);

        if (numbers.size() > 1) {
            operators.push_back(op);
        }

        cout << "Do you want to enter another number and operator? (y/n): ";
        cin >> choice;
    } while (choice == 'y' || choice == 'Y');

    // Calculate result
    float result = numbers[0];
    for (int i = 0; i < operators.size(); i++) {
        switch (operators[i]) {
            case '+':
                result += numbers[i + 1];
                break;
            case '-':
                result -= numbers[i + 1];
                break;
            case '*':
                result *= numbers[i + 1];
                break;
            case '/':
                if (numbers[i + 1] != 0) {
                    result /= numbers[i + 1];
                } else {
                    cout << "Error! Division by zero." << endl;
                    return 1; // Exit with error code
                }
                break;
            case '^':
                result = pow(result, numbers[i + 1]);
                break;
            case 's':
                result = sqrt(numbers[i + 1]);
                break;
            case 'c':
                result = cbrt(numbers[i + 1]);
                break;
            case 'S':
                result = sin(numbers[i + 1]);
                break;
            case 'C':
                result = cos(numbers[i + 1]);
                break;
            case 'T':
                result = tan(numbers[i + 1]);
                break;
            case 'A':
                result = asin(numbers[i + 1]);
                break;
            case 'B':
                result = acos(numbers[i + 1]);
                break;
            case 'M':
                result = atan(numbers[i + 1]);
                break;
            default:
                cout << "Invalid operator." << endl;
                return 1; // Exit with error code
        }
    }

    cout << "Result: " << result << endl;

    return 0;
}
